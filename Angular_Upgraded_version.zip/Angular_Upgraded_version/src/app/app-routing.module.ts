import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowDetailsComponent } from './show-details/show-details.component';
import { DepositeComponent } from './deposite/deposite.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferFundComponent } from './transfer-fund/transfer-fund.component';
import { TransactionComponent } from './transaction/transaction.component';


const routes: Routes = [
  { path:"app-create", component: CreateAccountComponent},
  { path:"app-show", component: ShowDetailsComponent },
  { path:"app-deposite", component: DepositeComponent },
  { path:"app-withdraw", component: WithdrawComponent },
  { path:"app-transfer-fund", component: TransferFundComponent},
  { path:"app-transaction", component: TransactionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
